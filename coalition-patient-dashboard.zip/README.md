# Tech.Care — Patient Healthcare Dashboard

> **Coalition Technologies Front-End Developer Skills Test**  
> **Application Type**: Single-Page Healthcare Dashboard  
> **Target Patient**: Jessica Taylor  
> **Tech Stack**: React 18, Vite, Chart.js, react-chartjs-2, CSS3  

---

## 🏥 Overview

Tech.Care is a responsive, single-page healthcare dashboard built to reproduce the provided Adobe XD reference design. The application dynamically fetches patient medical data from the Coalition Technologies Patient Data API, locates **Jessica Taylor**, and populates her demographic, diagnostic, and vital statistics into an interface.

### Key Features

1. **Authenticated REST API Integration**:
   - Sends an authenticated `GET` request to `https://fedskillstest.coalitiontechnologies.workers.dev`.
   - Generates the HTTP Basic Authentication header dynamically at runtime using `btoa` (`coalition:skills-test`) rather than hardcoding static credentials.
   - Robust error handling for network errors, failed HTTP responses, and loading states with an interactive retry option.

2. **Blood Pressure History Line Chart**:
   - Implemented using **Chart.js** and **react-chartjs-2**.
   - Chronologically sorts patient diagnosis history entries from oldest to newest.
   - Displays the last 6 months of data (`Oct, 2023` to `Mar, 2024`).
   - Renders dual datasets:
     - **Systolic** blood pressure (Pink line and points, e.g., 160 mmHg in March 2024).
     - **Diastolic** blood pressure (Purple line and points, e.g., 78 mmHg in March 2024).
   - Side panel summary showing latest readings, status levels, and directional trend indicators (`▲ Higher than Average`, `▼ Lower than Average`).

3. **Vital Signs Cards**:
   - **Respiratory Rate**: `20 bpm` (Normal) with stylized lung iconography on pale blue background (`#E0F3FA`).
   - **Temperature**: `98.6°F` (Normal) with thermometer iconography on pale peach background (`#FFE6E9`).
   - **Heart Rate**: `78 bpm` (Lower than Average) with heart/pulse iconography on light pink background (`#FFE6F1`).

4. **Diagnostic List Table**:
   - Structured table listing diagnosed conditions (`Hypertension`, `Type 2 Diabetes`, `Asthma`, etc.).
   - Includes Problem/Diagnosis, Description, and Status columns.
   - Features rounded table header and custom-styled vertical scrollbar.

5. **Patient Profile & Demographic Details**:
   - Displays Jessica Taylor's high-resolution avatar.
   - Formatted Date of Birth (`August 23, 1996`), Gender (`Female`), Contact Info (`(415) 555-1234`), Emergency Contact (`(415) 555-5678`), and Insurance Provider (`Sunrise Health Assurance`).
   - Full-width call-to-action button: *Show All Information*.

6. **Laboratory Results Panel**:
   - Displays all laboratory tests returned from the API (`Blood Tests`, `CT Scans`, `Radiology Reports`, `X-Rays`).
   - Download action triggers for each result row.

7. **Patient Navigation Sidebar**:
   - Displays the full list of patients retrieved from the API with their avatar, name, and demographic meta (`Gender, Age`).
   - **Jessica Taylor** is visually highlighted with the reference light turquoise active background (`#D8FCF7`).

8. **Fully Responsive Layout**:
   - **Desktop (1280px+)**: 3-column layout matching the Adobe XD artboard.
   - **Tablet (768px - 1080px)**: 2-column adaptive layout.
   - **Mobile (< 768px)**: Stacked single-column layout with horizontal scroll preservation for table data.

---

## 📁 Project Structure

```
coalition-patient-dashboard/
├── index.html                  # HTML entry point with Manrope typography
├── package.json                # Project dependencies and npm scripts
├── package-lock.json           # Locked dependency tree
├── vite.config.js              # Vite bundler configuration
├── test_suite.js               # Integration and helper verification suite
├── src/
│   ├── main.jsx                # Application mount entry
│   ├── App.jsx                 # Top-level state orchestration & error handling
│   ├── styles.css              # Custom styling matching Adobe XD specifications
│   ├── services/
│   │   └── patientApi.js       # Authenticated API fetching & runtime Basic Auth
│   ├── utils/
│   │   └── patientHelpers.js   # Date formatting, history sorting & chart transforms
│   └── components/
│       ├── Header.jsx          # Tech.Care brand, nav tabs & doctor profile
│       ├── PatientSidebar.jsx  # Scrollable patient directory
│       ├── DiagnosisHistory.jsx# Diagnosis history wrapper
│       ├── BloodPressureChart.jsx # Chart.js 2-dataset line chart
│       ├── VitalSigns.jsx      # Respiratory, temperature & heart rate cards
│       ├── DiagnosticList.jsx  # Diagnostic condition table
│       ├── PatientProfile.jsx  # Demographic details & profile card
│       └── LabResults.jsx      # Lab results with download actions
└── README.md                   # Project documentation
```

---

## 🚀 Getting Started

### Prerequisites

- **Node.js**: v18.0.0 or higher recommended.
- **npm**: v9.0.0 or higher.

### Installation

1. Clone or extract the project archive into your local workspace.
2. In the project root directory, install dependencies:
   ```bash
   npm install
   ```

### Running Locally (Development Mode)

Start the local Vite development server:
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000` (or the port specified in terminal).

### Running Verification Tests

To verify that the dynamic Basic Auth header generation, date manipulations, chronological sorting, and live API queries function properly:
```bash
node test_suite.js
```

### Production Build

Create an optimized, minified production build in the `dist/` directory:
```bash
npm run build
```

Preview the production build locally:
```bash
npm run preview
```

---

## 🎨 Design Specifications Implemented

- **Typography**: Google Font **Manrope** (Weights: `400 Regular`, `500 Medium`, `700 Bold`, `800 ExtraBold`).
- **Color Palette**:
  - Primary Dark Navy: `#072635`
  - Secondary Slate Gray: `#707079`
  - Accent Turquoise: `#01F0D0`
  - Selected Patient Pill: `#D8FCF7`
  - Background Neutral: `#F6F7F8`
  - Blood Pressure Card: `#F4F0FE`
  - Systolic Line / Points: `#C26EB4` / `#E66FD2`
  - Diastolic Line / Points: `#7E6CAB` / `#8C6FE6`
  - Vital Cards: `#E0F3FA` (Lungs), `#FFE6E9` (Temp), `#FFE6F1` (Heart)

---

## 🔒 Security Note

HTTP Basic Authentication credentials (`coalition:skills-test`) are encoded via Base64 at runtime in client code in accordance with the specific testing prompt instructions. In a real-world production environment, client-side exposure of API credentials would instead be proxied through a secure backend server or BFF (Backend-for-Frontend) layer.
